package lr.wcwl.com.lr.sdl.android.demo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import android.view.View;

import org.libsdl.app.SDLActivity;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 编译器原因

    }


//    public native void sdlPlayYUV(String inFilePath);


//    public void clickSDLTest(View v) {
//        startActivity(new Intent(this, SDLActivity.class));
//    }

    // 启动 SDL播放框架
    public void  clickSDLPlayer(View v) {

        startActivity(new Intent(this, SDLActivity.class));
    }


}
